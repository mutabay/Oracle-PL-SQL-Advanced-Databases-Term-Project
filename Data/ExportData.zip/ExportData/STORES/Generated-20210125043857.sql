--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STORES\STORES.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STORES\STORES_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STORES\SYS_C007340.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STORES\STORES_CONSTRAINT.sql
