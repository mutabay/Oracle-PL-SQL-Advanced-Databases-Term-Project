--------------------------------------------------------
--  Ref Constraints for Table ORDER_ITEMS
--------------------------------------------------------

  ALTER TABLE "MUTABAY"."ORDER_ITEMS" ADD CONSTRAINT "ORDERS" FOREIGN KEY ("ORDER_ID")
	  REFERENCES "MUTABAY"."ORDERS" ("ORDER_ID") ON DELETE CASCADE ENABLE;
  ALTER TABLE "MUTABAY"."ORDER_ITEMS" ADD FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "MUTABAY"."PRODUCTS" ("PRODUCT_ID") ON DELETE CASCADE ENABLE;
