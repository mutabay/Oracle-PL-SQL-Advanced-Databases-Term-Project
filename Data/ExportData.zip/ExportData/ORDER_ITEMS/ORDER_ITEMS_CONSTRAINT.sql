--------------------------------------------------------
--  Constraints for Table ORDER_ITEMS
--------------------------------------------------------

  ALTER TABLE "MUTABAY"."ORDER_ITEMS" MODIFY ("ORDER_ID" NOT NULL ENABLE);
  ALTER TABLE "MUTABAY"."ORDER_ITEMS" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
