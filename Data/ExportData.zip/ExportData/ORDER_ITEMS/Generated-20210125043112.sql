--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\ORDER_ITEMS\ORDER_ITEMS.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\ORDER_ITEMS\ORDER_ITEMS_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\ORDER_ITEMS\ORDER_ITEMS_CONSTRAINT.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\ORDER_ITEMS\ORDER_ITEMS_REFCONSTRAINT.sql
