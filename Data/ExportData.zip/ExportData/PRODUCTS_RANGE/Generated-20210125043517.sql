--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS_RANGE\PRODUCTS_RANGE.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS_RANGE\PRODUCTS_RANGE_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS_RANGE\SYS_C009147.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS_RANGE\PRODUCTS_RANGE_CONSTRAINT.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS_RANGE\PRODUCTS_RANGE_REFCONSTRAINT.sql
