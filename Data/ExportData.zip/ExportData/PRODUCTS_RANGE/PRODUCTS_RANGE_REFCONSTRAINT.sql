--------------------------------------------------------
--  Ref Constraints for Table PRODUCTS_RANGE
--------------------------------------------------------

  ALTER TABLE "MUTABAY"."PRODUCTS_RANGE" ADD FOREIGN KEY ("CATEGORY_ID")
	  REFERENCES "MUTABAY"."CATEGORIES" ("CATEGORY_ID") ON DELETE CASCADE ENABLE;
  ALTER TABLE "MUTABAY"."PRODUCTS_RANGE" ADD FOREIGN KEY ("BRAND_ID")
	  REFERENCES "MUTABAY"."BRANDS" ("BRAND_ID") ON DELETE CASCADE ENABLE;
