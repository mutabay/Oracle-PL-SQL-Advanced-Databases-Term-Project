--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS\PRODUCTS.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS\PRODUCTS_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS\SYS_C007332.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS\PRODUCTS_CONSTRAINT.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\PRODUCTS\PRODUCTS_REFCONSTRAINT.sql
