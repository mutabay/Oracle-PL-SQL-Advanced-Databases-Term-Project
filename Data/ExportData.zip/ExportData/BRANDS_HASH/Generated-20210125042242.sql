--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\BRANDS_HASH\BRANDS_HASH.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\BRANDS_HASH\BRANDS_HASH_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\BRANDS_HASH\SYS_C009009.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\BRANDS_HASH\BRANDS_HASH_CONSTRAINT.sql
