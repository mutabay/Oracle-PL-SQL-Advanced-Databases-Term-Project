--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CUSTOMERS\CUSTOMERS.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CUSTOMERS\CUSTOMERS_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CUSTOMERS\SYS_C007338.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CUSTOMERS\CUSTOMERS_CONSTRAINT.sql
