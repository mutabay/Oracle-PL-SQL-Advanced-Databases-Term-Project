--------------------------------------------------------
--  Ref Constraints for Table STAFFS
--------------------------------------------------------

  ALTER TABLE "MUTABAY"."STAFFS" ADD FOREIGN KEY ("STORE_ID")
	  REFERENCES "MUTABAY"."STORES" ("STORE_ID") ON DELETE CASCADE ENABLE;
  ALTER TABLE "MUTABAY"."STAFFS" ADD FOREIGN KEY ("MANAGER_ID")
	  REFERENCES "MUTABAY"."STAFFS" ("STAFF_ID") ENABLE;
