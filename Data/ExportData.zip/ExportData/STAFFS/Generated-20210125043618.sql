--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STAFFS\STAFFS.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STAFFS\STAFFS_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STAFFS\SYS_C009256.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STAFFS\STAFFS_CONSTRAINT.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STAFFS\STAFFS_REFCONSTRAINT.sql
