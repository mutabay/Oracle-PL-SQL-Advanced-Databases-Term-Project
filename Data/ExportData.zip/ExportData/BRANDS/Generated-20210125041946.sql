--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\BRANDS.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\BRANDS_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\SYS_C009006.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\BRANDS_CONSTRAINT.sql
