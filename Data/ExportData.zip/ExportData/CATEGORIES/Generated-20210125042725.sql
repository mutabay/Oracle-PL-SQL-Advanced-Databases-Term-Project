--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CATEGORIES\CATEGORIES.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CATEGORIES\CATEGORIES_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CATEGORIES\SYS_C007312.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\CATEGORIES\CATEGORIES_CONSTRAINT.sql
