--------------------------------------------------------
--  Constraints for Table STOCKS
--------------------------------------------------------

  ALTER TABLE "MUTABAY"."STOCKS" MODIFY ("STORE_ID" NOT NULL ENABLE);
  ALTER TABLE "MUTABAY"."STOCKS" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
  ALTER TABLE "MUTABAY"."STOCKS" ADD CONSTRAINT "SYS_C007384" PRIMARY KEY ("STORE_ID", "PRODUCT_ID") DISABLE;
