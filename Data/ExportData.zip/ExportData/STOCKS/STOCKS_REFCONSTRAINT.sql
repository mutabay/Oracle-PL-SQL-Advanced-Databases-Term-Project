--------------------------------------------------------
--  Ref Constraints for Table STOCKS
--------------------------------------------------------

  ALTER TABLE "MUTABAY"."STOCKS" ADD FOREIGN KEY ("STORE_ID")
	  REFERENCES "MUTABAY"."STORES" ("STORE_ID") ON DELETE CASCADE ENABLE;
  ALTER TABLE "MUTABAY"."STOCKS" ADD FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "MUTABAY"."PRODUCTS" ("PRODUCT_ID") ON DELETE CASCADE DISABLE;
