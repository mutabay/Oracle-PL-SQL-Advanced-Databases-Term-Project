--------------------------------------------------------
--  File created - Monday-January-25-2021   
--------------------------------------------------------
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STOCKS\STOCKS.sql
--@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STOCKS\STOCKS_DATA_TABLE.csv
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STOCKS\STOCKS_CONSTRAINT.sql
@C:\Users\tyyp-\Desktop\Repository\Advanced Database\Export\STOCKS\STOCKS_REFCONSTRAINT.sql
